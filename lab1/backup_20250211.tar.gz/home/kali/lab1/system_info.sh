#!/bin/bash
echo "System Report:"
echo "Kernel: $(uname -r)"
echo "User: $(whoami)"
echo "Date: $(date)"
