#!/bin/bash
tar -czvf backup_$(date +%Y%m%d).tar.gz /home/kali/lab1/
echo "Backup created!"
