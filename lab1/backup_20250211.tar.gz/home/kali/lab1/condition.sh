#!/bin/bash
if [ "$1" -gt 10 ]; then
  echo "$1 is greater than 10."
else
  echo "$1 is less than or equal to 10."
fi
