#!/bin/bash
echo "What's your name?"
read name
echo "Welcome, $name!"
